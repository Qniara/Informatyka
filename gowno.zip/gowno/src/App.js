import logo from './logo.svg';
import './App.css';

function App() {
  const bryly = [
    {nazwa: "Szescian",
      img: "img/szescian.png",
      wzory: "objetosc: V=a*a*a, pole: P=6(a*a)",
      przyklad: "a=2, V=8, P=24"
    },
    {
      nazwa: "Prostopadloscian",
      img: "img/prostopadloscian.png",
      wzory: "objetosc: V=a*b*h, pole: P=2*a*b+2*a*h+2*h*b",
      przyklad: "a=2, b=3, h=2, V=12, P=32"
    },
    {
      nazwa: "Kula",
      img: "img/kula.png",
      wzory: "objetosc: V=4/3*pi*r^3, pole: P=4*pi*r^2",
      przyklad: "r=3, V=113.04, P=113.04"
    }
  ];
  return (
    <div className='App'>
      <center>
        <h1>Bryly</h1>
        <table>
          <thead>
            <tr>
              <th>Bryla</th>
              <th>Ilustracja</th>
              <th>Wzory</th>
              <th>Przyklad</th>
            </tr>
          </thead>
        </table>
      </center>
    </div>
  );
}

export default App;
